let rows = [];

function refresh() {
  $.getJSON("/ajax_skills", function (response, textStatus, jqXHR) {
    $('#table').find("tr:gt(0)").remove();
    rows = response.data;
    response.data.forEach(skill => {
      let row = `<tr id="${skill.id}">`;
      row += `<td>${skill.id}</td>`;
      row += `<td>${skill.description}</td>`;
      row += '<td class="text-right">';
      row += `<button class="btn btn-warning edit">Edit</button>`;
      row += `<button class="btn btn-danger" onclick="removeSkill(${skill.id})">Delete</button>`;
      row += '</td>';
      row += '</tr>';
      $('#table').append(row);
    });
    clearForm();
  }
  );
}
function clearForm() {
  $('#description').val('');
  $('#id').val('');
  $('#form').addClass('d-none');
}

function save() {
  let description = $('#description').val();
  let id = $('#id').val();
  let token = $('input[name$="_token"]').val();
  let data = { description: description, _token: token };

  if (id == '') {
    $.post("/ajax_skills", data, function (data, textStatus, jqXHR) {
      //Possible solution is to add the new skill to the existing table
      refresh();
    },
    );
    return;
  }
  //edit
  $.ajax({
    type: "PUT",
    url: `/ajax_skills/${id}`,
    data: { _token: token, description: description }
  }).done(function (data) {
    refresh();
  });
}

function removeSkill(id) {
  if (confirm("are you sure?")) {
    let token = $('input[name$="_token"]').val();
    $.ajax({
      type: "DELETE",
      url: `/ajax_skills/${id}`,
      data: { _token: token }
    }).done(function (data) {
      refresh();
    });
  }
}

$('#new').click(function (e) {
  $('#form').removeClass('d-none');
  $('#description').focus();
});

$('#cancel').click(function (e) {
  clearForm();
});

$('#table').on('click', '.edit', function () {
  const id = $(this).parent().parent().attr('id');
  let item = rows.filter((row) => { return row.id == id });
  if (item) {
    $('#description').val(item[0].description);
    $('#id').val(item[0].id);
  }
  $('#form').removeClass('d-none');
  $('#description').focus();
});

refresh();
