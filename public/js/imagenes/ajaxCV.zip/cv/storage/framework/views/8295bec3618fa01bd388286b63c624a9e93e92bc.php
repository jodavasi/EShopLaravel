<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <title>New Skill</title>
</head>
<body>

<div class="container">
  <h2>New Skill</h2>
  
  <form method="POST" action="/skills/<?php echo e($skill->id); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <input class="form-control mb-2" type="text" name="description" placeholder="Skill description" value="<?php echo e($skill->description); ?>">

    <div>
      <button class="btn btn-primary">Save</button>
      <a class="btn btn-danger" href="/skills">Cancel</a>
    </div>
  </form>

</div>
</body>
</html>
<?php /**PATH /home/golabs/src/utn/cv/resources/views/skills/edit.blade.php ENDPATH**/ ?>