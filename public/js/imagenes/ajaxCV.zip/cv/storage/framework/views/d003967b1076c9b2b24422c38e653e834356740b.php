<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <title>Skills</title>
</head>
<body>

<div class="container pt-4">
  <div id="form" class="d-none pb-4">
    <?php echo csrf_field(); ?>
    <input type="hidden" id="id">
    <input class="form-control mb-2" type="text" id="description" placeholder="Skill description" value="">
    <div>
      <button id="save" class="btn btn-primary" onclick="save()">Save</button>
      <button id="cancel" class="btn btn-danger">Cancel</button>
    </div>
  </div>
  <h2>Skills</h2>
  <table class="table" id="table">
    <tr>
      <th>Id</th>
      <th>Description</th>
      <th>
        <div class="float-right">
          <button class="btn btn-dark" id="refresh" onclick="refresh()">Refresh</button>
          <button id="new" class="btn btn-success" >New</a>
        </div> 
      </th>
    </tr>
  </table>
</div>
<script src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
<script src="/js/ajax_skills/index.js"></script>
</body>
</html>
<?php /**PATH /home/golabs/src/utn/cv/resources/views/ajax_skills/index.blade.php ENDPATH**/ ?>