<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <title>Skills</title>
</head>
<body>

<div class="container">
  <h2>Skills</h2>
  <table class="table">
    <tr>
      <th>Id</th>
      <th>Description</th>
      <th>
         <a class="btn btn-success btn-block" href="/skills/create">New</a>
      </th>
    </tr>
    <?php $__empty_1 = true; $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
        <td><?php echo e($skill->id); ?></td>
        <td><?php echo e($skill->description); ?></td>
        <td>
          <a class="btn btn-secondary btn-block" href="/skills/<?php echo e($skill->id); ?>/edit">Edit</a>
          <form method="POST" action="/skills/<?php echo e($skill->id); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger  btn-block" >Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="2">No skills available!</td>
        </tr>
    <?php endif; ?>
  </table>
  <div class="d-flex justify-content-center">
    <?php echo e($skills->links()); ?>

  </div>

</div>
</body>
</html>
<?php /**PATH /home/golabs/src/utn/cv/resources/views/skills/index.blade.php ENDPATH**/ ?>